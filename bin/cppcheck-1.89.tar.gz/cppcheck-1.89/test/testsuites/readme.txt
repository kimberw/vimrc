Useful test cases taken from public test suites
