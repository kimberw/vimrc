
Systemtesting of Cppcheck CLI on some projects

addons
base path
exclude folders
importing projects
 * visual studio
 * compile database
   - different generators bear/cmake/..
   - different platforms
suppressions

Different paths:
 * relative
 * absolute

