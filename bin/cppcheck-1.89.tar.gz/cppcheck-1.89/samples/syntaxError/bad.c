int main()
{
#ifdef A
}
#endif
